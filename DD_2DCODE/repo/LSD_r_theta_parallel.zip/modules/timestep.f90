!*************************************************************************
!
!   X f* = Y f + N
!
!
!*************************************************************************
#include "../parallel.h"
 module timestep
!*************************************************************************
   use parameters
   use meshs
   use variables
   implicit none
   save

   double precision :: tim_t
   double precision :: tim_dt
   double precision :: tim_dterr
   integer          :: tim_it
   integer          :: tim_step
   double precision :: tim_corr_dt
   double precision :: tim_cfl_dt
   logical          :: tim_new_dt

 contains

!------------------------------------------------------------------------
!  set the initial time and timestep, 
!  possibly overwritten by loading a previously saved state
!------------------------------------------------------------------------
   subroutine tim_precompute()
      tim_t       = d_time
      tim_dt      = d_timestep
      tim_dterr   = 0d0
      tim_it      = 0
      tim_step    = 0
      tim_corr_dt = 0d0
      tim_cfl_dt  = 0d0
      tim_new_dt  = .false.
   end subroutine tim_precompute


!------------------------------------------------------------------------
!  Form the timestepping matrix  (c1/dt - c2 impl Laplace), for each l
!------------------------------------------------------------------------
   subroutine tim_lumesh_X(D,c1,c2,l,A)
      type (rdom),      intent(in)  :: D
      double precision, intent(in)  :: c1, c2
      integer,          intent(in)  :: l
      type (lumesh),    intent(out) :: A
      double precision :: c1_, c2_, ll1
      integer :: j

      c1_ =  c1 / tim_dt
      c2_ =  c2 * d_implicit
      if(d_implicit==0d0) c2_=1d0
      ll1 = dble(l*(l+1))

      A%M(i_KL+1:, :) = - c2_ * D%radLap%M
      A%M(2*i_KL+1,:) = A%M(2*i_KL+1,:) + c1_ + c2_*ll1*D%r(:,-2)

      do j = 1, 1+i_KL
         A%M(2*i_KL+1+1-j,j) = 0d0
      end do
      do j = D%N-i_KL, D%N
         A%M(2*i_KL+1+D%N-j,j) = 0d0
      end do

   end subroutine tim_lumesh_X


!------------------------------------------------------------------------
!  Form the timestepping matrix  (c1/dt - c2 impl Laplace), for each l
!------------------------------------------------------------------------
   subroutine tim_iclumesh_X(c1,c2,l,A)
      double precision, intent(in)  :: c1, c2
      integer,          intent(in)  :: l
      type (iclumesh),  intent(out) :: A
      double precision :: c1_, c2_, ll1
      integer :: j, N_, Ni, No
      
      Ni  = mes_ic%N
      No  = mes_oc%N
      N_  = Ni+No-1
      c1_ =  c1 / tim_dt
      c2_ =  c2 * d_implicit
      if(d_implicit==0d0) c2_=1d0
      ll1 = dble(l*(l+1))

      A%M = 0d0
      A%M(i_KL+1:, :Ni) = - c2_ * mes_ic%radLap%M(:,:Ni)
      A%M(2*i_KL+1,:Ni) = A%M(2*i_KL+1,:Ni)  &
                        + c1_ + c2_*ll1*mes_ic%r(:Ni,-2)

      if(Ni==1) A%M=0d0
      A%M(i_KL+1:, Ni:N_) = A%M(i_KL+1:, Ni:N_)  &
                          - c2_*mes_oc%radLap%M(:,:No)
      A%M(2*i_KL+1,Ni:N_) = A%M(2*i_KL+1,Ni:N_)  &
                          + c1_ + c2_*ll1*mes_oc%r(:No,-2)
      do j = 1, 1+i_KL
         A%M(2*i_KL+1+1-j,j) = 0d0
      end do
      do j = N_-i_KL, N_
         A%M(2*i_KL+1+N_-j,j) = 0d0
      end do
      if(Ni==1) return
      do j = Ni-i_KL, Ni+i_KL
         A%M(2*i_KL+1+Ni-j,j) = 0d0
      end do

   end subroutine tim_iclumesh_X


!------------------------------------------------------------------------
!  Form the matrix  c1/dt + c2 (1-impl) Laplace, for each l
!------------------------------------------------------------------------
   subroutine tim_mesh_Y(D,c1,c2,l,A)
      type (rdom),      intent(in)  :: D
      double precision, intent(in)  :: c1, c2
      integer,          intent(in)  :: l
      type (mesh),      intent(out) :: A
      double precision :: c1_, c2_

      c1_ =  c1 / tim_dt
      c2_ =  c2 * (1d0-d_implicit)

      A%M = c2_ * D%radLap%M
      A%M(i_KL+1,:) = A%M(i_KL+1,:) + c1_ - c2_*l*(l+1)*D%r(:,-2)

   end subroutine tim_mesh_Y


!------------------------------------------------------------------------
!  solve system Ax=y for x, replaces b,  includes l=m=0 mode if(zero)
!  uses lapack routine dgbtrs()
!------------------------------------------------------------------------
   subroutine tim_invX(zero,A, b)
      logical,       intent(in)    :: zero
      type (coll),   intent(inout) :: b
      type (lumesh), intent(in)    :: A(0:i_L1)
      integer :: info
      _loop_lm_vars

      _loop_lm_begin(b)
         if( l==0 .and. .not.zero) cycle
         call dgbtrs('N', b%D%N, i_KL, i_KL, 1, A(l)%M, 3*i_KL+1,  &
                     A(l)%ipiv, b%Re(1,nh), b%D%N, info )
         if(info/=0) stop 'tim_invX.1'
         call dgbtrs('N', b%D%N, i_KL, i_KL, 1, A(l)%M, 3*i_KL+1,  &
                     A(l)%ipiv, b%Im(1,nh), b%D%N, info )
         if(info/=0) stop 'tim_invX.2'
      _loop_lm_end
   
   end subroutine tim_invX


!------------------------------------------------------------------------
!  solve system Ax=y for x, replaces b,  includes l=m=0 mode if(zero)
!------------------------------------------------------------------------
   subroutine tim_icinvX(zero,A, oc,ic)
      logical,         intent(in)    :: zero
      type (coll),     intent(inout) :: oc,ic
      type (iclumesh), intent(in)    :: A(0:i_L1)
      double precision :: b(mes_ic%N+mes_oc%N-1)
      integer :: info, N_,Ni,No
      _loop_lm_vars
      
      Ni = mes_ic%N
      No = mes_oc%N
      N_ = Ni+No-1

      _loop_lm_begin(oc)
         if( l==0 .and. .not.zero) cycle
            
         b(1:Ni-1) = ic%Re(1:Ni-1,nh)
         b(Ni:N_)  = oc%Re(1:No,  nh)
         call dgbtrs('N', N_, i_KL, i_KL, 1, A(l)%M, 3*i_KL+1,  &
                     A(l)%ipiv, b, N_, info )
         if(info/=0) stop 'tim_invX.1'
         ic%Re(1:Ni,nh) = b(1:Ni)
         oc%Re(1:No,nh) = b(Ni:N_)

         b(1:Ni-1) = ic%Im(1:Ni-1,nh)
         b(Ni:N_)  = oc%Im(1:No,  nh)
         call dgbtrs('N', N_, i_KL, i_KL, 1, A(l)%M, 3*i_KL+1,  &
                     A(l)%ipiv, b, N_, info )
         if(info/=0) stop 'tim_invX.2'
         ic%Im(1:Ni,nh) = b(1:Ni)
         oc%Im(1:No,nh) = b(Ni:N_)
      _loop_lm_end

   end subroutine tim_icinvX


!------------------------------------------------------------------------
!  multiply d = Ab + c,  includes l=m=0 mode if(zero)
!  uses lapack routine dgbtrs()
!------------------------------------------------------------------------
   subroutine tim_multY(zero,A,b,c, d)
      logical,     intent(in)  :: zero
      type (coll), intent(in)  :: b,c
      type (mesh), intent(in)  :: A(0:i_L1)
      type (coll), intent(out) :: d
      integer :: j,nl,nr,n
      _loop_lm_vars

      call var_coll_copy(c, d)

      _loop_lm_begin(b)
         if( l==0 .and. .not.zero) cycle
         do j = 1, d%D%N
            nl = max(1,j-i_KL)
            nr = min(j+i_KL,d%D%N)
            do n = nl, nr
               d%Re(n,nh)  &
                  = d%Re(n,nh) + A(l)%M(i_KL+1+n-j,j) * b%Re(j,nh)
               d%Im(n,nh)  &
                  = d%Im(n,nh) + A(l)%M(i_KL+1+n-j,j) * b%Im(j,nh)
            end do
         end do
      _loop_lm_end
 
   end subroutine tim_multY


!-------------------------------------------------------------------------
!  set the RHS for the boundary condition = 0
!-------------------------------------------------------------------------
   subroutine tim_zerobc(a)
      type (coll), intent(inout) :: a
      integer :: N_, n
      N_  = a%D%N
      do n = 0, a%H%pH1
         a%Re(  1, n ) = 0d0
         a%Re( N_, n ) = 0d0
         a%Im(  1, n ) = 0d0
         a%Im( N_, n ) = 0d0
      end do
   end subroutine tim_zerobc
   
   

!-------------------------------------------------------------------------
!  get the nonlinear correction:  nc := c ( n - np )
!-------------------------------------------------------------------------
   subroutine tim_nlincorr(n,np, nc)
      type (coll), intent(in)  :: n, np
      type (coll), intent(out) :: nc
      integer :: r, nhm
      nc%D => n%D
      nc%H => n%H
      r   = n%D%N
      nhm = n%H%pH1
      nc%Re(1:r,0:nhm) = d_implicit * (n%Re(1:r,0:nhm) - np%Re(1:r,0:nhm))
      nc%Im(1:r,0:nhm) = d_implicit * (n%Im(1:r,0:nhm) - np%Im(1:r,0:nhm))
   end subroutine tim_nlincorr
   

!-------------------------------------------------------------------------
!  add the correction:  a := a + ac
!-------------------------------------------------------------------------
   subroutine tim_addcorr(ac, a)
      type (coll), intent(in)    :: ac
      type (coll), intent(inout) :: a
      double precision :: dterr, d
      integer :: nh, n
      dterr = 0d0
      do nh = 0, a%H%pH1
         do n = 1, a%D%N
            dterr = dterr + ac%Re(n,nh)*ac%Re(n,nh)
            dterr = dterr + ac%Im(n,nh)*ac%Im(n,nh)
            a%Re(n,nh) = a%Re(n,nh) + ac%Re(n,nh)
            a%Im(n,nh) = a%Im(n,nh) + ac%Im(n,nh)
         end do
      end do
#ifdef _MPI
      call mpi_allreduce(dterr, d, 1, mpi_double_precision,  &
         mpi_sum, mpi_comm_world, mpi_er)
      dterr = d
#endif
      tim_dterr = tim_dterr + dsqrt(dterr)
   end subroutine tim_addcorr


!-------------------------------------------------------------------------
!  check for convergence via the 2-norm of the correction
!  -- see tim_addcorr()
!-------------------------------------------------------------------------
   subroutine tim_check_cgce()
      double precision, save :: lasterr
      
      if(tim_it==1) then
         tim_corr_dt = tim_dt * dsqrt( d_dterr/tim_dterr )
         lasterr = 1d99
      end if         

      if(tim_dt<1d-9 .and. tim_step>30) then
         if(mpi_rnk==0) print*, 'tim_check_cgce: dt --> 0 !!!?'
         tim_step = i_maxtstep-1
         tim_it = 0      
      else if(tim_it>10) then
         if(mpi_rnk==0) print*, 'tim_check_cgce: too many its!!!'
         tim_step = i_maxtstep-1
         tim_it = 0
      else if(tim_dterr>lasterr) then
         if(mpi_rnk==0) print*, 'tim_check_cgce: increasing error!!!'
         if(tim_dterr>2d0*d_dterr) tim_step = i_maxtstep-1
         if(tim_dterr<2d0*d_dterr) tim_corr_dt = tim_dt/(1d1*d_courant)
         tim_it = 0
      else if(tim_dterr>d_dterr) then
         lasterr = tim_dterr
         tim_it = tim_it + 1
      else          
         if(mpi_rnk==0 .and. modulo(tim_step,i_save_rate2)==0) then
            if(d_timestep> 0d0) print*,' step=',tim_step,' its=',tim_it
            if(d_timestep<=0d0) print*,' step=',tim_step,' dt=',real(tim_dt)
         end if
         tim_it = 0
      end if
      tim_dterr = 0d0
      
   end subroutine tim_check_cgce

!-------------------------------------------------------------------------
!
!-------------------------------------------------------------------------
   subroutine tim_new_tstep()
      double precision :: dt
      
      dt = tim_dt   
      if(tim_corr_dt>0d0)  dt = min(tim_corr_dt, dt*2d0/d_courant)
      if(tim_cfl_dt >0d0)  dt = min(tim_cfl_dt, dt)
      if(tim_step == 0  )  dt = min(dt/1d3, 1d-10)
      dt = dt * d_courant
      
      tim_new_dt = (dt<tim_dt*0.97d0 .or. dt>tim_dt*1.03d0)
      if(tim_new_dt)  tim_dt = dt
      
   end subroutine tim_new_tstep


!*************************************************************************
 end module timestep
!*************************************************************************

